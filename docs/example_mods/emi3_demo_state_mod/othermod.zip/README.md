original demo mod by emi3 for her fnf psych engine fork

modified by bobbyDX [me] to be compatible with lumen engine [this thing]