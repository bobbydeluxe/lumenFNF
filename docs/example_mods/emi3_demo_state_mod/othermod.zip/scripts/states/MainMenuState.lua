function onCreatePost()
	setProperty('menuItems.members[0].flipY', true)
	funnyFunction() -- check scripts/global/globalTest.hx
end